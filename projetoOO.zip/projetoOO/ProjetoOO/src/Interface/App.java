import java.awt.event.*;
import java.swing.*;
import java.event.*;
import java.scene.*;
import java.stage.*;
import java.fxml.*;


public class App extends Aplicattion {

  public static void main (String[] args) throws Exception {
    lunch(args);
  }

  @Override
  public void start(stage primaryStage) throws Exception {
    FXMLLoaderLoader loader = new FXMLLoaderLoader(getClass().getRessource("layout.fxml"));
    Parent root = fxml.Loader.load();
    Scence tela = new Scene(root);

    primaryStage.setTicle("Erick Teste de janela");
    primaryStage.setScene(tela);
    primaryStage.show();

  }

}